typedef unsigned long long Set;

Set buscar(int a[], int n);

